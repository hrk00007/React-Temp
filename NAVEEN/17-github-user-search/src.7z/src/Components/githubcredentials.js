export const clientID = '9a40a98dcca138e59de7';
export const clientSecret = 'daed7b7bdacb0c438c0c751ca1a6aed2480b263a';
